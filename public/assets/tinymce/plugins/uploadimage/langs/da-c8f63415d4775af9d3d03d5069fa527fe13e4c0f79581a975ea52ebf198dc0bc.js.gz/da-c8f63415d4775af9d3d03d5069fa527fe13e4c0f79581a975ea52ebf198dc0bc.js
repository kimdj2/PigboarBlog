tinyMCE.addI18n('da', {
  'Insert an image from your computer': 'Inds\u00e6t billede fra computer',
  'Insert image': "Inds\u00e6t billede",
  'Choose an image': "V\u00e6lg billede",
  'You must choose a file': "Du skal v\u00e6lge en fil",
  'Got a bad response from the server': "Modtog et ugyldigt svar fra serveren",
  "Didn't get a response from the server": "Modtog ikke et svar fra serveren",
  'Insert': "Indsæt",
  'Cancel': "Annuller",
  'Image description': "Alternativ billedtekst",
  'Insert an video from your computer': 'Inds\u00e6t video/lyd fra computer',
  'Insert video': "Ind\u00e6t video/lyd",
  'Choose an image': "V\u00e6lg video/lyd"
});
