(function() {
  $(function() {
    return alert('dd');
  });

}).call(this);
